from django.urls import path
from . import views

urlpatterns = [
    path('dashboard/', views.dashboard, name='dashboard'),
    path('income/', views.income, name='income'),
    path('savings/', views.savings, name='savings'),
    path('expenditure/', views.expenditure, name='expenditure'),
    path('properties/', views.properties, name='properties'),
    # ... other URL patterns ...
]

# Create your views here.
from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from .models import Finance  # Ensure Finance model exists

@login_required
def dashboard(request):
    try:
        # Fetch finance data (example)
        finance_data = Finance.objects.all()
        return render(request, 'finance/dashboard'
        '.html', {'finance_data': finance_data})
    except Exception as e:
        print(f"Error loading dashboard: {e}")  # This will log in the console
        return render(request, 'finance/error.html', {'error': str(e)})

@login_required
def income(request):
    return render(request, 'finance/income.html', {
        'user': request.user,
        'page_title': 'Income'
    })

@login_required
def savings(request):
    return render(request, 'finance/savings.html', {
        'user': request.user,
        'page_title': 'Savings'
    })

@login_required
def expenditure(request):
    return render(request, 'finance/expenditure.html', {
        'user': request.user,
        'page_title': 'Expenditure'
    })

@login_required
def properties(request):
    return render(request, 'finance/properties.html', {
        'user': request.user,
        'page_title': 'Properties'
    })

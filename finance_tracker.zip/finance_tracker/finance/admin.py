from django.contrib import admin
from .models import Account, Transaction, Category, BillReminder, Budget, SavingsGoal

admin.site.register(Account)
admin.site.register(Transaction)
admin.site.register(Category)
admin.site.register(BillReminder)
admin.site.register(Budget)
admin.site.register(SavingsGoal)
